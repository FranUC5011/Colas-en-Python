from collections import deque

cola = deque([10, 20, 30, 40, 50])

pila = []

while cola:
    pila.append(cola.popleft())

while pila:
    cola.append(pila.pop())

print(cola)