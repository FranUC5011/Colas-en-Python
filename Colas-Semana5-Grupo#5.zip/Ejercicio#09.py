from collections import deque
import math

cola = deque([444, 958, 1648, 2597, 3677])

cola_temp = deque()
cola_aux = deque()

while cola:
    elemento = cola.popleft()
    cola_temp.append(math.sqrt(elemento))
    cola_aux.append(elemento)

cola = cola_aux

print("Cola original:", cola)
print("Cola con raíces:", cola_temp)