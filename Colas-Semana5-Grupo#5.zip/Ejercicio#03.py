from collections import deque

cola = deque([6854, 7452, 9874, 8795, 4585, 3215, 8820])

if cola:
    mayor = max(cola)
    cola.append(mayor)

print(cola)