from collections import deque

cola = deque([6810, 7950, 2430, 3340, 1520])

if cola:
    menor = min(cola)
    cola.appendleft(menor)

print(cola)