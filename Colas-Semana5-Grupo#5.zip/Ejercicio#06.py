from collections import deque

cola = deque(["Luis", "Ana", "Carlos", "Alberto", "Maria"])

nombre_encontrado = None
cola_aux = deque()

while cola:
    nombre = cola.popleft()
    if nombre_encontrado is None and (nombre[0] == 'A' or nombre[0] == 'a'):
        nombre_encontrado = nombre
    else:
        cola_aux.append(nombre)

if nombre_encontrado is not None:
    cola_aux.append(nombre_encontrado)

cola = cola_aux

print(cola)