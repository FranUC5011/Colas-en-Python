from collections import deque

cola = deque([1150, 2848, 3058, 4890, 5890, 6875, 7899, 8888])

print(len(cola))