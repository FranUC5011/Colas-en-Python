from collections import deque

cola = deque(["Sarah", "James", "Ana", "David", "Sophia", "William", "Daniel"])

nombre_encontrado = None
cola_aux = deque()

while cola:
    nombre = cola.popleft()
    if nombre_encontrado is None and (nombre[0] == 'A' or nombre[0] == 'a'):
        nombre_encontrado = nombre
    else:
        cola_aux.append(nombre)

if nombre_encontrado is not None:
    cola = deque([nombre_encontrado])
    cola.extend(cola_aux)
else:
    cola = cola_aux

print(cola)