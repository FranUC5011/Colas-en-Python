from collections import deque

cola = deque([0, 10, 0, 20, 0, 30, 40, 0])

cola_aux = deque()

while cola:
    elemento = cola.popleft()
    if elemento != 0:
        cola_aux.append(elemento)

cola = cola_aux

print(cola)